{% set url_ajax = ucfunc("get_url_ajax") %}
 
{{ ucfunc("put_docready_start") }}
    	  
  var objAjaxSearch = new UEAjaxSearch();
  objAjaxSearch.init("{{url_ajax}}","{{uc_id}}","{{uc_url_home}}");
      
{{ ucfunc("put_docready_end") }}