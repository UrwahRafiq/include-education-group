{# twig vars #}{##}
{% set addstyle = "style='display:none'" %}
{% set addstyle_loader = "style='display:none'" %}
    
{% if uc_inside_editor == "yes" and debug_list == "true" %}
	{% set addstyle = "" %}
{% endif %}    

{% if uc_inside_editor == "yes" and debug_loader == "true" %}
	{% set addstyle_loader = "" %}
{% endif %}  

{% set loaderElem %}<svg class="uc-ajax-search__spinner" viewBox="0 0 50 50"><circle class="uc-ajax-search__spinner-path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>{% endset %}
{# end twig vars #}{##}

<div id="{{uc_id}}" class="uc-ajax-search-wrapper {% if enable_filters == 'true' %} uc-filterable-grid uc-grid-norefresh {% endif %}">
  <div class="uc-ajax-search-wrapper-inside">

    {% if show_search_label == "true" %}<span class="uc-ajax-search__title">{{search_label|raw}}</span>{% endif %}

    <div class="uc-ajax-search__input-wrapper">

      <div class="uc-ajax-search__input-wrapper-inner"> 
        <input type="text" class="uc-ajax-search__input" value="" aria-label="search" placeholder="{{search_placeholder}}" data-open-homeurl="{{search_button_open_new_window}}">
        <div class="uc-ajax-search__spinner__loader-wrapper" {{addstyle_loader|raw}}>{{loaderElem}}</div>
      </div>

      {% if show_search_button == "true" %}
        <button type="button" aria-label="button" class="uc-ajax-search__btn uc-inactive" name="search-btn" value="" data-page-url="{{search_button_page_url|raw}}"><span class="uc-ajax-search__btn_icon">{{search_button_icon_html|raw}}</span>{{search_button_text|raw}}</button> 
      {% endif %}	

      <div class="uc-ajax-search__error" style="display:none"></div>    

      <div class="uc-ajax-search__items uc-items-wrapper" {{addstyle|raw}} data-pagination="{{show_pagination}}" data-num-items="{{items_number_per_page}}" data-debug-list="{{debug_list}}" data-editor="{{uc_inside_editor}}" data-keys="{{keys_control}}" data-pagination-position="{{pagination_position}}" data-no-results-text="{{no_results_text|raw}}" data-results-text="{{results_text|raw}}" data-autocorrect="{{search_autocorrect}}" data-autocorrect-beforetext="{{autocorrection_text_before|raw}}" data-autocorrect-aftertext="{{autocorrection_text_after|raw}}" data-goto-on-enter="{{go_to_on_enter}}" data-bold-phrase="{{mark_bold_search_phrase}}" data-linksending="{{custom_links_ending}}" data-linksendingtext="{{custom_links_ending_text|raw}}">
        {{put_items()}}
      </div>

    </div>

    {% if show_suggested_searches == "true" %}
      <div class="uc-ajax-search__suggested-wrapper">
        <div class="uc-ajax-search__suggested-label">{{suggested_label|raw}}</div>
        <div class="uc-ajax-search__suggested">{{suggested_searches|raw}}</div>
      </div>
    {% endif %}	

  </div>
</div>